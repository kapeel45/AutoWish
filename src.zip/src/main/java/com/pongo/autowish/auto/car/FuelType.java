package com.pongo.autowish.auto.car;

public enum FuelType {
	  PETROL, DIESEL, CNG, LPG, ELECTRIC 
}
