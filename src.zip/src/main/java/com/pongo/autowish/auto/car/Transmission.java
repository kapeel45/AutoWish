package com.pongo.autowish.auto.car;

public enum Transmission {
		AUTO,
		MANUAL
}
