package com.pongo.autowish.user;

public class UserDto {

}
