package com.pongo.autowish.document;

public enum DocumentType {
	  AAD,
	  DL, 
	  PAN,
	   VID,
	   CID,
	   OTHER
}
